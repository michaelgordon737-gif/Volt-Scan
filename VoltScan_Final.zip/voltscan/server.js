const http = require("http");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");

const PORT = Number(process.env.PORT || 3000);
const MASSIVE_API_KEY = process.env.MASSIVE_API_KEY || "";
const PUBLIC_DIR = path.join(__dirname, "public");
const UA = "VoltScan/0.2";

const mime = {
  ".html":"text/html; charset=utf-8", ".css":"text/css; charset=utf-8",
  ".js":"application/javascript; charset=utf-8", ".json":"application/json; charset=utf-8",
  ".svg":"image/svg+xml", ".png":"image/png", ".ico":"image/x-icon"
};

const cache = {
  refs: { at:0, data:[] },
  floats: { at:0, map:new Map() },
  snapshot: { at:0, data:[], error:null }
};

function sendJson(res,status,data){
  res.writeHead(status,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});
  res.end(JSON.stringify(data));
}
function safeSymbol(v){ return String(v||"").toUpperCase().replace(/[^A-Z0-9.\-]/g,"").slice(0,15); }
function n(v){ const x=Number(v); return Number.isFinite(x)?x:null; }

async function massiveFetch(pathOrUrl){
  if(!MASSIVE_API_KEY) throw new Error("NO_API_KEY");
  const u = pathOrUrl.startsWith("http") ? new URL(pathOrUrl) : new URL(`https://api.massive.com${pathOrUrl}`);
  if(!u.searchParams.has("apiKey")) u.searchParams.set("apiKey",MASSIVE_API_KEY);
  const r = await fetch(u,{headers:{"User-Agent":UA}});
  if(!r.ok){ const t=await r.text(); const e=new Error(`Massive API ${r.status}: ${t.slice(0,260)}`); e.status=r.status; throw e; }
  return r.json();
}

async function fetchAllPages(firstPath,maxPages=30){
  let url=firstPath, out=[], pages=0;
  while(url && pages++<maxPages){
    const d=await massiveFetch(url);
    if(Array.isArray(d.results)) out.push(...d.results);
    url=d.next_url||null;
  }
  return out;
}

async function getReferenceUniverse(){
  if(Date.now()-cache.refs.at < 12*60*60*1000 && cache.refs.data.length) return cache.refs.data;
  const rows=await fetchAllPages("/v3/reference/tickers?market=stocks&active=true&limit=1000&sort=ticker",30);
  cache.refs={at:Date.now(),data:rows};
  return rows;
}

async function getFloatMap(){
  if(Date.now()-cache.floats.at < 6*60*60*1000 && cache.floats.map.size) return cache.floats.map;
  const rows=await fetchAllPages("/stocks/vX/float?limit=5000&sort=ticker.asc",10);
  const map=new Map();
  for(const r of rows){ if(r.ticker) map.set(r.ticker,{free_float:n(r.free_float),free_float_percent:n(r.free_float_percent),effective_date:r.effective_date||null}); }
  cache.floats={at:Date.now(),map};
  return map;
}

async function getFullSnapshot(){
  if(Date.now()-cache.snapshot.at < 60_000 && (cache.snapshot.data.length || cache.snapshot.error)) return {rows:cache.snapshot.data,error:cache.snapshot.error};
  try{
    const d=await massiveFetch("/v2/snapshot/locale/us/markets/stocks/tickers?include_otc=false");
    const rows=Array.isArray(d.tickers)?d.tickers:[];
    cache.snapshot={at:Date.now(),data:rows,error:null};
    return {rows,error:null};
  }catch(e){
    cache.snapshot={at:Date.now(),data:cache.snapshot.data||[],error:e.message};
    return {rows:cache.snapshot.data,error:e.message};
  }
}

const demoSymbols=["OFA","PLAG","NVDA","AMD","AAPL","TSLA","MSFT","AMZN","META","SOFI","RGTI","IONQ","ACHR","RKLB","SMCI","MARA","RIOT","COIN","HOOD","GME","AMC","SOUN","QBTS","BBAI","LCID","NIO","F","BAC","INTC","MU"];
const demoBase={OFA:3.84,PLAG:6.21,NVDA:184.42,AMD:177.16,AAPL:231.18,TSLA:328.44,MSFT:521.23,AMZN:225.10,META:758.20,SOFI:24.31};
function hashSymbol(sym){ return [...sym].reduce((a,c)=>((a*31)+c.charCodeAt(0))>>>0,7); }
function demoFloat(sym){ const h=hashSymbol(sym); return {free_float:1_500_000+(h%180_000_000),free_float_percent:25+(h%7300)/100,effective_date:"DEMO"}; }
function demoSnapshot(sym){
  const h=hashSymbol(sym), base=demoBase[sym]||(1+(h%30000)/100), now=Date.now();
  const wave=Math.sin((now/48000)+h)*(0.004+(h%17)/3000), burst=((h+Math.floor(now/180000))%11===0)?0.03:0;
  const price=Math.max(.05,base*(1+wave+burst)), daily=(((h%3200)-800)/100)+wave*100+burst*100;
  const prev=price/(1+daily/100), open=prev*(1+((h%300)-120)/10000), high=Math.max(price,open)*(1.01+(h%20)/1000), low=Math.min(price,open)*(0.99-(h%12)/1200);
  const prevVol=400000+(h%9_000_000), dayVol=Math.round(prevVol*(.2+(h%260)/100)), minOpen=price/(1+wave*1.8);
  return {ticker:sym,todaysChangePerc:daily,todaysChange:price-prev,updated:now*1_000_000,day:{o:open,h:high,l:low,c:price,v:dayVol},prevDay:{c:prev,v:prevVol},min:{o:minOpen,h:Math.max(price,minOpen)*1.002,l:Math.min(price,minOpen)*.998,c:price,v:2000+(h%180000),av:dayVol},lastTrade:{p:price}};
}
function demoRef(sym){ return {ticker:sym,name:`${sym} Demo Company`,market:"stocks",locale:"us",primary_exchange:(hashSymbol(sym)%2?"XNAS":"XNYS"),type:"CS",active:true,currency_name:"usd"}; }
function demoUniverse(){ return demoSymbols.map(s=>({...demoRef(s),snapshot:demoSnapshot(s),float:demoFloat(s)})); }

function demoBars(sym, interval="5m", count=72){
  const spec={"1m":[1,"minute"],"5m":[5,"minute"],"15m":[15,"minute"],"30m":[30,"minute"],"1h":[1,"hour"],"1d":[1,"day"]}[interval]||[5,"minute"];
  const stepMs=spec[1]==="day"?86400000:spec[1]==="hour"?3600000:spec[0]*60000;
  const h=hashSymbol(sym), base=demoBase[sym]||(1+(h%30000)/100), now=Date.now();
  let price=base*(.96+((h%80)/1000));
  const out=[];
  for(let i=count-1;i>=0;i--){
    const t=now-i*stepMs;
    const idx=count-1-i;
    const wave=Math.sin(idx*.48+h*.07)*(.006+(h%9)/2600);
    const drift=(idx/count)*(((h%17)-6)/900);
    const o=Math.max(.03,price);
    const c=Math.max(.03,o*(1+wave+drift/count));
    const spread=.0025+Math.abs(Math.sin(idx*.73+h))*.006;
    const hi=Math.max(o,c)*(1+spread);
    const lo=Math.min(o,c)*(1-spread*.85);
    const v=Math.round((25000+(h%420000))*(.45+Math.abs(Math.sin(idx*.31+h*.13))*2.2));
    out.push({t,o,h:hi,l:lo,c,v});
    price=c;
  }
  return out;
}

function barRange(interval){
  const map={
    "1m":{multiplier:1,timespan:"minute",lookbackMs:2*60*60*1000},
    "5m":{multiplier:5,timespan:"minute",lookbackMs:8*60*60*1000},
    "15m":{multiplier:15,timespan:"minute",lookbackMs:2*24*60*60*1000},
    "30m":{multiplier:30,timespan:"minute",lookbackMs:4*24*60*60*1000},
    "1h":{multiplier:1,timespan:"hour",lookbackMs:8*24*60*60*1000},
    "1d":{multiplier:1,timespan:"day",lookbackMs:120*24*60*60*1000}
  };
  return map[interval]||map["5m"];
}

function normalizeRow(ref,snap,flt){
  const ticker=(snap&&snap.ticker)||(ref&&ref.ticker)||"";
  const price=n(snap?.lastTrade?.p ?? snap?.min?.c ?? snap?.day?.c);
  return {
    ticker,
    name:ref?.name||"",
    type:ref?.type||"",
    exchange:ref?.primary_exchange||"",
    price,
    changePct:n(snap?.todaysChangePerc),
    volume:n(snap?.day?.v ?? snap?.min?.av),
    minuteOpen:n(snap?.min?.o),
    minuteClose:n(snap?.min?.c),
    prevVolume:n(snap?.prevDay?.v),
    float:flt?.free_float ?? null,
    floatPct:flt?.free_float_percent ?? null,
    floatDate:flt?.effective_date ?? null,
    raw:snap||null
  };
}

function filterAndSort(rows,url){
  let out=rows;
  const q=(url.searchParams.get("search")||"").trim().toLowerCase();
  const priceMax=n(url.searchParams.get("priceMax")), priceMin=n(url.searchParams.get("priceMin"));
  const floatMax=n(url.searchParams.get("floatMax")), floatMin=n(url.searchParams.get("floatMin"));
  const volumeMin=n(url.searchParams.get("volumeMin"));
  const gainMin=n(url.searchParams.get("gainMin"));
  const commonOnly=url.searchParams.get("commonOnly")==="true";
  if(q) out=out.filter(r=>r.ticker.toLowerCase().includes(q)||r.name.toLowerCase().includes(q));
  if(priceMin!==null) out=out.filter(r=>r.price!==null&&r.price>=priceMin);
  if(priceMax!==null) out=out.filter(r=>r.price!==null&&r.price<=priceMax);
  if(floatMin!==null) out=out.filter(r=>r.float!==null&&r.float>=floatMin);
  if(floatMax!==null) out=out.filter(r=>r.float!==null&&r.float<=floatMax);
  if(volumeMin!==null) out=out.filter(r=>r.volume!==null&&r.volume>=volumeMin);
  if(gainMin!==null) out=out.filter(r=>r.changePct!==null&&r.changePct>=gainMin);
  if(commonOnly) out=out.filter(r=>r.type==="CS");
  const sort=url.searchParams.get("sort")||"gain";
  const cmp={
    gain:(a,b)=>(b.changePct??-Infinity)-(a.changePct??-Infinity),
    volume:(a,b)=>(b.volume??-Infinity)-(a.volume??-Infinity),
    float:(a,b)=>(a.float??Infinity)-(b.float??Infinity),
    price:(a,b)=>(a.price??Infinity)-(b.price??Infinity),
    ticker:(a,b)=>a.ticker.localeCompare(b.ticker)
  }[sort]||((a,b)=>a.ticker.localeCompare(b.ticker));
  return out.sort(cmp);
}

async function liveUniverse(){
  const refs=await getReferenceUniverse();
  let floatMap=new Map();
  try{ floatMap=await getFloatMap(); }catch(e){}
  const {rows:snapshotRows,error:snapshotError}=await getFullSnapshot();
  const snapMap=new Map(snapshotRows.map(s=>[s.ticker,s]));
  const refMap=new Map(refs.map(r=>[r.ticker,r]));
  const tickers=new Set([...refMap.keys(),...snapMap.keys()]);
  const rows=[];
  for(const t of tickers) rows.push(normalizeRow(refMap.get(t),snapMap.get(t),floatMap.get(t)));
  return {rows,snapshotError,priceDataAvailable:snapshotRows.length>0};
}

async function handleApi(req,res,url){
  if(url.pathname==="/api/status") return sendJson(res,200,{mode:MASSIVE_API_KEY?"live":"demo",provider:"Massive",hasApiKey:!!MASSIVE_API_KEY});

  if(url.pathname==="/api/market"){
    try{
      const source=MASSIVE_API_KEY?await liveUniverse():{rows:demoUniverse().map(x=>normalizeRow(x,x.snapshot,x.float)),snapshotError:null,priceDataAvailable:true};
      const filtered=filterAndSort(source.rows,url);
      const page=Math.max(1,Number(url.searchParams.get("page")||1)), limit=Math.min(200,Math.max(10,Number(url.searchParams.get("limit")||50)));
      const start=(page-1)*limit;
      return sendJson(res,200,{status:"OK",mode:MASSIVE_API_KEY?"live":"demo",priceDataAvailable:source.priceDataAvailable,snapshotError:source.snapshotError,total:filtered.length,page,limit,rows:filtered.slice(start,start+limit)});
    }catch(e){ return sendJson(res,502,{error:e.message}); }
  }

  if(url.pathname==="/api/gainers"){
    if(!MASSIVE_API_KEY){
      const rows=demoUniverse().map(x=>normalizeRow(x,x.snapshot,x.float)).sort((a,b)=>(b.changePct||0)-(a.changePct||0)).slice(0,30);
      return sendJson(res,200,{status:"OK",mode:"demo",rows,tickers:rows.map(r=>r.raw)});
    }
    try{
      const source=await liveUniverse();
      if(source.priceDataAvailable){
        const rows=source.rows.filter(r=>(r.volume||0)>=10000&&r.changePct!==null).sort((a,b)=>b.changePct-a.changePct).slice(0,100);
        return sendJson(res,200,{status:"OK",mode:"live",rows,tickers:rows.map(r=>r.raw).filter(Boolean),priceDataAvailable:true});
      }
      return sendJson(res,200,{status:"OK",mode:"live",rows:[],tickers:[],priceDataAvailable:false,error:source.snapshotError});
    }catch(e){ return sendJson(res,502,{error:e.message}); }
  }

  if(url.pathname==="/api/snapshots"){
    const syms=[...new Set((url.searchParams.get("symbols")||"").split(",").map(safeSymbol).filter(Boolean).slice(0,50))];
    if(!syms.length) return sendJson(res,400,{error:"No symbols supplied."});
    if(!MASSIVE_API_KEY) return sendJson(res,200,{status:"OK",mode:"demo",tickers:syms.map(demoSnapshot)});
    try{
      const q=encodeURIComponent(syms.join(","));
      const d=await massiveFetch(`/v2/snapshot/locale/us/markets/stocks/tickers?tickers=${q}`);
      return sendJson(res,200,{...d,mode:"live"});
    }catch(e){ return sendJson(res,502,{error:e.message}); }
  }


  if(url.pathname.startsWith("/api/bars/")){
    const sym=safeSymbol(decodeURIComponent(url.pathname.split("/").pop()));
    const interval=String(url.searchParams.get("interval")||"5m");
    if(!sym) return sendJson(res,400,{error:"Invalid symbol."});
    if(!["1m","5m","15m","30m","1h","1d"].includes(interval)) return sendJson(res,400,{error:"Unsupported interval."});
    if(!MASSIVE_API_KEY) return sendJson(res,200,{status:"OK",mode:"demo",symbol:sym,interval,bars:demoBars(sym,interval)});
    try{
      const r=barRange(interval), to=Date.now(), from=to-r.lookbackMs;
      const d=await massiveFetch(`/v2/aggs/ticker/${encodeURIComponent(sym)}/range/${r.multiplier}/${r.timespan}/${from}/${to}?adjusted=true&sort=asc&limit=5000`);
      const bars=(d.results||[]).slice(-120).map(x=>({t:n(x.t),o:n(x.o),h:n(x.h),l:n(x.l),c:n(x.c),v:n(x.v)})).filter(x=>x.t&&x.o!==null&&x.h!==null&&x.l!==null&&x.c!==null);
      return sendJson(res,200,{status:"OK",mode:"live",symbol:sym,interval,bars});
    }catch(e){ return sendJson(res,502,{error:e.message}); }
  }

  if(url.pathname.startsWith("/api/ticker/")){
    const sym=safeSymbol(decodeURIComponent(url.pathname.split("/").pop()));
    if(!sym) return sendJson(res,400,{error:"Invalid symbol."});
    if(!MASSIVE_API_KEY){
      return sendJson(res,200,{status:"OK",mode:"demo",ticker:demoSnapshot(sym),details:demoRef(sym),float:demoFloat(sym)});
    }
    try{
      const [snapSettled,detailSettled,floatSettled]=await Promise.allSettled([
        massiveFetch(`/v2/snapshot/locale/us/markets/stocks/tickers/${encodeURIComponent(sym)}`),
        massiveFetch(`/v3/reference/tickers/${encodeURIComponent(sym)}`),
        massiveFetch(`/stocks/vX/float?ticker=${encodeURIComponent(sym)}&limit=1`)
      ]);
      const snap=snapSettled.status==="fulfilled"?snapSettled.value.ticker:null;
      const details=detailSettled.status==="fulfilled"?detailSettled.value.results:null;
      const fl=floatSettled.status==="fulfilled"?(floatSettled.value.results||[])[0]||null:null;
      if(!snap&&!details&&!fl) throw new Error("No data returned for ticker.");
      return sendJson(res,200,{status:"OK",mode:"live",ticker:snap,details,float:fl});
    }catch(e){ return sendJson(res,502,{error:e.message}); }
  }

  return sendJson(res,404,{error:"Unknown API route."});
}

function serveStatic(req,res,url){
  let rel=decodeURIComponent(url.pathname); if(rel==="/") rel="/index.html";
  const normalized=path.normalize(rel).replace(/^(\.\.[/\\])+/,"");
  const filePath=path.join(PUBLIC_DIR,normalized);
  if(!filePath.startsWith(PUBLIC_DIR)){res.writeHead(403);return res.end("Forbidden");}
  fs.stat(filePath,(err,stat)=>{
    if(err||!stat.isFile()){res.writeHead(404,{"Content-Type":"text/plain; charset=utf-8"});return res.end("Not found");}
    const ext=path.extname(filePath).toLowerCase();
    res.writeHead(200,{"Content-Type":mime[ext]||"application/octet-stream","Cache-Control":ext===".html"?"no-cache":"public, max-age=300"});
    fs.createReadStream(filePath).pipe(res);
  });
}

http.createServer(async(req,res)=>{
  const url=new URL(req.url,`http://${req.headers.host||"localhost"}`);
  if(url.pathname.startsWith("/api/")) return handleApi(req,res,url);
  return serveStatic(req,res,url);
}).listen(PORT,()=>{
  console.log(`VoltScan Final running at http://localhost:${PORT}`);
  console.log(`Market mode: ${MASSIVE_API_KEY?"LIVE / API CONNECTED":"DEMO"}`);
});
