# VoltScan Final

Bug-fix release: restores stock-row/detail-page clicks and keeps the candle/line chart controls.

# VoltScan v0.2

Phone-friendly stock scanner / PWA focused on volatility, market movers, custom watchlists and low-float stocks.

## New in v0.2

- New **Market** page for the provider's full active U.S. stock/security universe.
- Search by ticker or company name.
- Paginated results instead of trying to render 10,000+ rows at once.
- **Free Float** and **Float %** displayed in the market table.
- Float filters: under 5M, 10M, 20M, 50M, or 50M+.
- Price and volume filters.
- Sort by % gain, volume, lowest float, price, or ticker.
- Common-stock-only filter.
- Stock detail page now shows Free Float and Float % prominently.
- Top Gainers now derives from the full-market snapshot when the API plan supports it, instead of depending only on the provider's Top 20 endpoint.
- Demo data is clearly labeled as simulated so it cannot be mistaken for current market movers.

## Important data-plan behavior

VoltScan uses Massive for the current adapter.

- The active ticker/reference list can be used to browse the stock universe with an API key.
- Massive's experimental free-float endpoint supplies `free_float`, `free_float_percent`, and an effective date.
- The full-market snapshot is required for market-wide live/delayed price, change, volume, and calculated top movers.
- If the API key does not have full-market snapshot access, VoltScan will still show the reference stock list and float where available, but price/change/volume will be blank on the full-market page.
- Real-time versus delayed market prices depend on the provider plan.

## Run it

Requires Node.js 18+.

Open a Terminal in this `voltscan` folder and run:

```powershell
node server.js
```

Then open:

```text
http://localhost:3000
```

Without an API key the app runs in **SIMULATED DEMO** mode.

## Add your Massive API key on Windows PowerShell

Close VoltScan first with `Ctrl+C` in the Terminal.

Then run:

```powershell
$env:MASSIVE_API_KEY="YOUR_KEY_HERE"
node server.js
```

Keep that Terminal open while using the app.

To confirm the key is being used, the top-right badge in VoltScan will change from **DEMO** to **LIVE**.

## Market page

Use the **Market** button in the bottom navigation.

The table contains:

- Ticker / company
- Price
- Today's % change
- Volume
- Free Float
- Float %
- Add-to-watchlist button

Useful low-float scan example:

- Float: `< 10M`
- Price: `$1–$5`
- Volume: `500K+`
- Sort: `Top % gain`

This creates a useful small-cap momentum scanner when the market snapshot feed is available.

## What free float means

Free float is the estimated number of shares considered freely tradable after excluding strategic, controlling, restricted, locked-up and certain large ownership blocks. It is not necessarily updated trade-by-trade; ownership disclosures can create a reporting lag.

## Notifications

The current PWA can issue browser notifications while the app is actively scanning. Reliable alerts while the app is completely closed still require the next backend stage: a continuously running server scanner plus Web Push / FCM / APNs.


## v0.5 click fix
Stock rows now use a direct click handler in addition to delegated keyboard/click handling, and the PWA service-worker cache version is bumped and old caches are removed on activation.
